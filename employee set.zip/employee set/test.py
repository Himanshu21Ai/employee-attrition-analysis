import pandas as pd
import matplotlib.pyplot as plt



df = pd.read_csv("dataset/IBM.csv")
print(df.info())


